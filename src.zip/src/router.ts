import { useEffect, useState } from 'react'

// A tiny hash router: pages live at addresses like  #/movie-recap
// Hash routing needs no server setup, so the built site works on any static host.

function currentPath(): string {
  const raw = window.location.hash.replace(/^#/, '')
  if (raw === '') return '/'
  const withoutQuery = raw.split('?')[0]
  const withSlash = withoutQuery.startsWith('/') ? withoutQuery : `/${withoutQuery}`
  return withSlash.length > 1 ? withSlash.replace(/\/+$/, '') || '/' : withSlash
}

export function useRoute(): string {
  const [path, setPath] = useState(currentPath)

  useEffect(() => {
    const onChange = () => setPath(currentPath())
    window.addEventListener('hashchange', onChange)
    return () => window.removeEventListener('hashchange', onChange)
  }, [])

  return path
}

export function hrefFor(path: string): string {
  return `#${path}`
}
