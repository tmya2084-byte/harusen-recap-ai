import { useEffect, useId, useState } from 'react'
import Badge from './Badge'

const supported = typeof window !== 'undefined' && 'speechSynthesis' in window

/**
 * Reads text aloud with the voice built into the phone's browser.
 * This is NOT the Harusen AI voice engine; it only lets you hear how a script sounds.
 */
export default function VoicePreview() {
  const fieldId = useId()
  const [text, setText] = useState('')
  const [speaking, setSpeaking] = useState(false)

  // Stop talking if the person leaves the page.
  useEffect(() => {
    return () => {
      if (supported) window.speechSynthesis.cancel()
    }
  }, [])

  function speak() {
    if (!supported || text.trim() === '') return
    window.speechSynthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.onend = () => setSpeaking(false)
    utterance.onerror = () => setSpeaking(false)
    setSpeaking(true)
    window.speechSynthesis.speak(utterance)
  }

  function stop() {
    if (!supported) return
    window.speechSynthesis.cancel()
    setSpeaking(false)
  }

  return (
    <section className="card">
      <div className="card__head">
        <h2>Listen on your device</h2>
        <Badge tone="info">Browser voice, not Harusen AI</Badge>
      </div>
      <p className="muted small">
        Type a short line and your phone will read it aloud using its own built-in voice. The
        voice and language depend on your phone's text-to-speech settings. Nothing is recorded or
        saved.
      </p>

      {supported ? (
        <>
          <label className="visually-hidden" htmlFor={fieldId}>
            Text to read aloud
          </label>
          <textarea
            id={fieldId}
            className="textarea textarea--short"
            value={text}
            onChange={(event) => setText(event.target.value)}
            placeholder="Type a line to hear it read aloud…"
            rows={4}
          />
          <div className="btn-row">
            <button
              type="button"
              className="btn btn--primary"
              onClick={speak}
              disabled={text.trim() === '' || speaking}
            >
              {speaking ? 'Speaking…' : 'Read aloud'}
            </button>
            <button type="button" className="btn" onClick={stop} disabled={!speaking}>
              Stop
            </button>
          </div>
        </>
      ) : (
        <p className="notice notice--error" role="alert">
          This browser does not offer built-in speech, so the listen preview is unavailable.
        </p>
      )}
    </section>
  )
}
