import { useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import Icon from './Icon'
import { NAV_ITEMS } from '../nav'
import { hrefFor } from '../router'

interface AppShellProps {
  path: string
  children: ReactNode
}

// The three pages that get a quick shortcut in the bottom bar on phones.
// Every page is still reachable from the menu.
const QUICK_PATHS = ['/', '/movie-recap', '/projects']
const QUICK_ITEMS = NAV_ITEMS.filter((item) => QUICK_PATHS.includes(item.path))

export default function AppShell({ path, children }: AppShellProps) {
  const [menuOpen, setMenuOpen] = useState(false)
  const current = NAV_ITEMS.find((item) => item.path === path)

  // On every page change: close the menu, scroll to the top, update the tab title.
  useEffect(() => {
    setMenuOpen(false)
    window.scrollTo(0, 0)
    document.title = current ? `${current.label} · Harusen Recap AI` : 'Harusen Recap AI'
  }, [path, current])

  // While the phone menu is open: Escape closes it and the page behind does not scroll.
  useEffect(() => {
    if (!menuOpen) return
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setMenuOpen(false)
    }
    window.addEventListener('keydown', onKeyDown)
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKeyDown)
      document.body.style.overflow = previousOverflow
    }
  }, [menuOpen])

  return (
    <div className="app">
      <a
        className="skip-link"
        href="#main"
        onClick={(event) => {
          // A normal "#main" link would change the page address, so focus it by hand.
          event.preventDefault()
          document.getElementById('main')?.focus()
        }}
      >
        Skip to content
      </a>

      <header className="topbar">
        <button
          type="button"
          className="icon-btn menu-btn"
          aria-label={menuOpen ? 'Close menu' : 'Open menu'}
          aria-expanded={menuOpen}
          aria-controls="side-nav"
          onClick={() => setMenuOpen((open) => !open)}
        >
          <Icon name={menuOpen ? 'close' : 'menu'} />
        </button>
        <a className="brand" href={hrefFor('/')}>
          <span className="brand__mark" aria-hidden="true">
            H
          </span>
          <span className="brand__name">Harusen Recap AI</span>
        </a>
        <span className="chip">Stage 1</span>
      </header>

      <div className="notice-bar" role="note">
        <strong>Preview build.</strong> AI and video processing are not connected yet.
      </div>

      <div className="layout">
        <nav id="side-nav" className={menuOpen ? 'sidenav sidenav--open' : 'sidenav'} aria-label="Main">
          <ul className="sidenav__list">
            {NAV_ITEMS.map((item) => (
              <li key={item.path}>
                <a
                  href={hrefFor(item.path)}
                  className="navlink"
                  aria-current={item.path === path ? 'page' : undefined}
                >
                  <Icon name={item.icon} size={20} />
                  <span>{item.label}</span>
                </a>
              </li>
            ))}
          </ul>
        </nav>

        {menuOpen ? (
          <button
            type="button"
            className="backdrop"
            aria-label="Close menu"
            onClick={() => setMenuOpen(false)}
          />
        ) : null}

        <main id="main" tabIndex={-1} className="content">
          {children}
        </main>
      </div>

      <nav className="tabbar" aria-label="Quick links">
        {QUICK_ITEMS.map((item) => (
          <a
            key={item.path}
            href={hrefFor(item.path)}
            className="tab"
            aria-current={item.path === path ? 'page' : undefined}
          >
            <Icon name={item.icon} size={22} />
            <span>{item.label}</span>
          </a>
        ))}
        <button type="button" className="tab" onClick={() => setMenuOpen(true)} aria-expanded={menuOpen} aria-controls="side-nav">
          <Icon name="menu" size={22} />
          <span>All tools</span>
        </button>
      </nav>
    </div>
  )
}
