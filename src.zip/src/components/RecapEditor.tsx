import { useId, useState } from 'react'
import type { ChangeEvent } from 'react'
import Badge from './Badge'
import { countWords, formatClock } from '../lib/format'
import { addExport, deleteDraft, downloadTextFile, loadDraft, saveDraft } from '../lib/storage'

type SaveState = 'idle' | 'saved' | 'failed'

interface RecapEditorProps {
  /** Unique id for this editor, e.g. "movie-recap". Used to save the draft. */
  storageKey: string
  title: string
  /** Name shown for this draft in Projects and Export History. */
  draftLabel: string
  /** Page address used by the "Open" link in Projects, e.g. "/movie-recap". */
  pagePath: string
  placeholder: string
  extension?: 'txt' | 'srt'
  helpText?: string
}

/**
 * A plain text editor. It saves automatically in this browser (localStorage)
 * and can download the text as a file. No AI is involved.
 */
export default function RecapEditor({
  storageKey,
  title,
  draftLabel,
  pagePath,
  placeholder,
  extension = 'txt',
  helpText,
}: RecapEditorProps) {
  const fieldId = useId()
  const [initialDraft] = useState(() => loadDraft(storageKey))
  const [text, setText] = useState(initialDraft?.text ?? '')
  const [savedAt, setSavedAt] = useState<number | null>(initialDraft?.updatedAt ?? null)
  const [saveState, setSaveState] = useState<SaveState>(initialDraft ? 'saved' : 'idle')
  const [notice, setNotice] = useState('')

  const hasText = text.trim() !== ''
  const words = countWords(text)
  const characters = Array.from(text).length

  function persist(next: string) {
    const now = Date.now()
    const ok = saveDraft({
      key: storageKey,
      label: draftLabel,
      path: pagePath,
      extension,
      text: next,
      updatedAt: now,
    })
    if (!ok) {
      setSaveState('failed')
      return
    }
    if (next.trim() === '') {
      setSaveState('idle')
      setSavedAt(null)
    } else {
      setSaveState('saved')
      setSavedAt(now)
    }
  }

  function handleChange(event: ChangeEvent<HTMLTextAreaElement>) {
    const next = event.target.value
    setText(next)
    setNotice('')
    persist(next)
  }

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(text)
      setNotice('Copied to your clipboard.')
    } catch {
      setNotice(
        'Your browser blocked copying. Press and hold in the text box, choose Select all, then Copy.',
      )
    }
  }

  function handleDownload() {
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')
    const filename = `${storageKey}-${stamp}.${extension}`
    const mime = extension === 'srt' ? 'application/x-subrip' : 'text/plain'
    const bytes = downloadTextFile(filename, text, mime)
    addExport({ filename, at: Date.now(), bytes, source: draftLabel })
    setNotice(`Download requested: ${filename}. Look in your browser's Downloads.`)
  }

  function handleClear() {
    if (!window.confirm('Clear this text? This cannot be undone.')) return
    setText('')
    setSavedAt(null)
    setSaveState('idle')
    setNotice('')
    deleteDraft(storageKey)
  }

  let statusText = 'Nothing saved yet.'
  if (saveState === 'saved' && savedAt !== null) {
    statusText = `Saved on this device at ${formatClock(savedAt)}.`
  } else if (saveState === 'failed') {
    statusText =
      'Could not save. Your browser may be blocking local storage, so copy your text somewhere safe.'
  }

  return (
    <section className="card">
      <div className="card__head">
        <h2>{title}</h2>
        <Badge tone="local">Works on your device</Badge>
      </div>
      <p className="muted small">
        {helpText ??
          'Type or paste your text below. It is saved in this browser only; nothing is sent to a server.'}
      </p>

      <label className="visually-hidden" htmlFor={fieldId}>
        {title}
      </label>
      <textarea
        id={fieldId}
        className="textarea"
        value={text}
        onChange={handleChange}
        placeholder={placeholder}
        spellCheck={extension === 'txt'}
        rows={10}
      />

      <div className="editor-meta">
        <span>{words} words</span>
        <span>{characters} characters</span>
      </div>
      <p className="muted small" role="status" aria-live="polite">
        {statusText}
      </p>

      <div className="btn-row">
        <button type="button" className="btn btn--primary" onClick={handleDownload} disabled={!hasText}>
          Download .{extension}
        </button>
        <button type="button" className="btn" onClick={handleCopy} disabled={!hasText}>
          Copy
        </button>
        <button type="button" className="btn btn--danger" onClick={handleClear} disabled={!hasText}>
          Clear
        </button>
      </div>

      {notice ? (
        <p className="notice" role="status">
          {notice}
        </p>
      ) : null}
    </section>
  )
}
