import type { ReactNode } from 'react'

/**
 * off   = not connected to a real service (amber, so it stands out)
 * local = works on this device only
 * info  = neutral information
 */
export type BadgeTone = 'off' | 'local' | 'info'

interface BadgeProps {
  tone?: BadgeTone
  children: ReactNode
}

export default function Badge({ tone = 'info', children }: BadgeProps) {
  return <span className={`badge badge--${tone}`}>{children}</span>
}
