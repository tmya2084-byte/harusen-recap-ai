import { useId } from 'react'
import Badge from './Badge'

export interface PlannedFeature {
  label: string
  description: string
}

interface FeaturePanelProps {
  title?: string
  features: PlannedFeature[]
}

/**
 * Lists features that need a real AI or video-processing service.
 * Every button is switched off on purpose: nothing here produces a result.
 */
export default function FeaturePanel({ title = 'Planned features', features }: FeaturePanelProps) {
  const headingId = useId()

  return (
    <section className="card card--planned" aria-labelledby={headingId}>
      <div className="card__head">
        <h2 id={headingId}>{title}</h2>
        <Badge tone="off">Not connected</Badge>
      </div>
      <p className="muted small">
        These need a real AI or video-processing service, which is not connected yet. The buttons
        are switched off and nothing here creates results.
      </p>
      <ul className="feature-list">
        {features.map((feature) => (
          <li key={feature.label} className="feature">
            <button
              type="button"
              className="btn btn--ghost"
              disabled
              aria-label={`${feature.label} (not connected)`}
            >
              {feature.label}
            </button>
            <span className="muted small">{feature.description}</span>
          </li>
        ))}
      </ul>
    </section>
  )
}
