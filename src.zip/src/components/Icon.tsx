export type IconName =
  | 'dashboard'
  | 'movie'
  | 'drama'
  | 'clip'
  | 'copy'
  | 'transcript'
  | 'voice'
  | 'subtitle'
  | 'blur'
  | 'editor'
  | 'projects'
  | 'exports'
  | 'menu'
  | 'close'
  | 'upload'

const PATHS: Record<IconName, string> = {
  dashboard: 'M4 4h7v7H4z M13 4h7v4h-7z M13 10h7v10h-7z M4 13h7v7H4z',
  movie: 'M4 5h16v14H4z M8 5v14 M16 5v14 M4 9h4 M4 15h4 M16 9h4 M16 15h4',
  drama: 'M3 6h18v12H3z M10 9.5v5l4.5-2.5z',
  clip: 'M4 6a2 2 0 1 0 4 0a2 2 0 1 0-4 0 M4 18a2 2 0 1 0 4 0a2 2 0 1 0-4 0 M7.5 7.5L20 17 M7.5 16.5L20 7',
  copy: 'M9 9h11v11H9z M5 15V5h10',
  transcript: 'M4 6h16 M4 10h16 M4 14h10 M4 18h7',
  voice: 'M12 3a3 3 0 0 0-3 3v5a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3z M6 11a6 6 0 0 0 12 0 M12 17v4',
  subtitle: 'M3 6h18v12H3z M7 12h3 M13 12h4 M7 15h6',
  blur: 'M12 3c3 4 6 6.5 6 10a6 6 0 0 1-12 0c0-3.5 3-6 6-10z',
  editor: 'M4 7h10 M18 7h2 M4 17h2 M10 17h10 M14 5v4 M6 15v4',
  projects: 'M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z',
  exports: 'M12 4v10 M8 10l4 4 4-4 M4 18h16',
  menu: 'M4 7h16 M4 12h16 M4 17h16',
  close: 'M6 6l12 12 M18 6L6 18',
  upload: 'M12 16V5 M8 9l4-4 4 4 M4 19h16',
}

interface IconProps {
  name: IconName
  size?: number
}

export default function Icon({ name, size = 22 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
    >
      <path d={PATHS[name]} />
    </svg>
  )
}
