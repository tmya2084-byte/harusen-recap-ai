import { useEffect, useId, useRef, useState } from 'react'
import type { ChangeEvent, DragEvent } from 'react'
import Badge from './Badge'
import Icon from './Icon'
import { formatBytes, formatDuration } from '../lib/format'

interface VideoUploadProps {
  title?: string
  /** Also accept audio files (used by Transcript Studio). */
  allowAudio?: boolean
}

const VIDEO_EXTENSIONS = /\.(mp4|m4v|mov|webm|mkv|avi|3gp)$/i
const AUDIO_EXTENSIONS = /\.(mp3|m4a|wav|ogg|aac|flac)$/i

function isAccepted(file: File, allowAudio: boolean): boolean {
  if (file.type.startsWith('video/')) return true
  if (allowAudio && file.type.startsWith('audio/')) return true
  // Some Android file pickers report no type, so fall back to the file name.
  if (file.type === '') {
    return VIDEO_EXTENSIONS.test(file.name) || (allowAudio && AUDIO_EXTENSIONS.test(file.name))
  }
  return false
}

/**
 * Lets the person pick a video and preview it in this browser tab.
 * The file is never uploaded, stored or processed anywhere.
 */
export default function VideoUpload({ title = 'Video upload', allowAudio = false }: VideoUploadProps) {
  const inputId = useId()
  const headingId = useId()
  const inputRef = useRef<HTMLInputElement>(null)
  const [file, setFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [duration, setDuration] = useState<number | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [dragging, setDragging] = useState(false)

  // Release the temporary preview address when it changes or the page closes.
  useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl)
    }
  }, [previewUrl])

  const kind = allowAudio ? 'video or audio file' : 'video'

  function choose(picked: File | undefined) {
    if (!picked) return
    if (!isAccepted(picked, allowAudio)) {
      setError(`That file does not look like a ${kind}. Please choose another one.`)
      return
    }
    setError(null)
    setDuration(null)
    setFile(picked)
    setPreviewUrl(URL.createObjectURL(picked))
  }

  function handleInputChange(event: ChangeEvent<HTMLInputElement>) {
    choose(event.target.files?.[0])
    // Allow choosing the same file again later.
    event.target.value = ''
  }

  function handleDragOver(event: DragEvent<HTMLLabelElement>) {
    event.preventDefault()
    setDragging(true)
  }

  function handleDrop(event: DragEvent<HTMLLabelElement>) {
    event.preventDefault()
    setDragging(false)
    choose(event.dataTransfer.files[0])
  }

  function remove() {
    setFile(null)
    setPreviewUrl(null)
    setDuration(null)
    setError(null)
  }

  return (
    <section className="card" aria-labelledby={headingId}>
      <div className="card__head">
        <h2 id={headingId}>{title}</h2>
        <Badge tone="local">Preview only</Badge>
      </div>

      <input
        id={inputId}
        ref={inputRef}
        type="file"
        accept={allowAudio ? 'video/*,audio/*' : 'video/*'}
        className="visually-hidden"
        onChange={handleInputChange}
      />

      {file === null ? (
        <label
          htmlFor={inputId}
          className={dragging ? 'dropzone dropzone--active' : 'dropzone'}
          onDragOver={handleDragOver}
          onDragLeave={() => setDragging(false)}
          onDrop={handleDrop}
        >
          <Icon name="upload" size={32} />
          <span className="dropzone__title">Tap to choose a {kind}</span>
          <span className="muted small">or drop a file here on a computer</span>
        </label>
      ) : (
        <div className="preview">
          {previewUrl ? (
            <video
              className="preview__video"
              src={previewUrl}
              controls
              playsInline
              preload="metadata"
              onLoadedMetadata={(event) => setDuration(event.currentTarget.duration)}
              onError={() =>
                setError(
                  'This browser cannot play that file for preview. The file itself was not changed.',
                )
              }
            />
          ) : null}
          <dl className="file-info">
            <div>
              <dt>Name</dt>
              <dd>{file.name}</dd>
            </div>
            <div>
              <dt>Size</dt>
              <dd>{formatBytes(file.size)}</dd>
            </div>
            <div>
              <dt>Type</dt>
              <dd>{file.type || 'Unknown'}</dd>
            </div>
            <div>
              <dt>Length</dt>
              <dd>{formatDuration(duration)}</dd>
            </div>
          </dl>
          <div className="btn-row">
            <button type="button" className="btn" onClick={() => inputRef.current?.click()}>
              Choose a different file
            </button>
            <button type="button" className="btn btn--danger" onClick={remove}>
              Remove
            </button>
          </div>
        </div>
      )}

      {error ? (
        <p className="notice notice--error" role="alert">
          {error}
        </p>
      ) : null}

      <p className="muted small">
        Stage 1: the file is only previewed in this browser tab. It is not uploaded, stored or
        processed anywhere, and it is forgotten when you reload the page.
      </p>
    </section>
  )
}
