import type { ReactNode } from 'react'

interface PageHeaderProps {
  title: string
  subtitle: string
  badges?: ReactNode
}

export default function PageHeader({ title, subtitle, badges }: PageHeaderProps) {
  return (
    <header className="page-header">
      <h1>{title}</h1>
      <p className="page-header__sub">{subtitle}</p>
      {badges ? <div className="badge-row">{badges}</div> : null}
    </header>
  )
}
