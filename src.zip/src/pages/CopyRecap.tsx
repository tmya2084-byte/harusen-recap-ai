import { useId, useState } from 'react'
import Badge from '../components/Badge'
import FeaturePanel from '../components/FeaturePanel'
import PageHeader from '../components/PageHeader'
import RecapEditor from '../components/RecapEditor'

export default function CopyRecap() {
  const sourceId = useId()
  const [source, setSource] = useState('')

  return (
    <>
      <PageHeader
        title="Copy Recap"
        subtitle="Keep an existing recap next to your own version and rewrite it by hand."
        badges={
          <>
            <Badge tone="local">Editor works</Badge>
            <Badge tone="off">AI rewrite not connected</Badge>
          </>
        }
      />

      <section className="card">
        <div className="card__head">
          <h2>Original text</h2>
          <Badge tone="info">Not saved</Badge>
        </div>
        <p className="muted small">
          Paste a recap you want to adapt. This box is only a reference for you; it is not saved
          and nothing is done to it.
        </p>
        <label className="visually-hidden" htmlFor={sourceId}>
          Original text
        </label>
        <textarea
          id={sourceId}
          className="textarea textarea--short"
          value={source}
          onChange={(event) => setSource(event.target.value)}
          placeholder="Paste the original recap here…"
          rows={6}
        />
      </section>

      <RecapEditor
        storageKey="copy-recap"
        title="Your version"
        draftLabel="Copy Recap draft"
        pagePath="/copy-recap"
        placeholder="Write your own version of the recap here…"
      />

      <FeaturePanel
        features={[
          {
            label: 'Rewrite with AI',
            description: 'Would rewrite the original in fresh wording. Needs an AI text service.',
          },
          {
            label: 'Change tone or length',
            description: 'Would make the recap shorter, longer or more dramatic. Needs an AI text service.',
          },
          {
            label: 'Translate recap',
            description: 'Would translate the recap into another language. Needs an AI text service.',
          },
        ]}
      />
    </>
  )
}
