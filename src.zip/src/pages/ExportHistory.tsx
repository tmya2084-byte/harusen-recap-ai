import { useState } from 'react'
import Badge from '../components/Badge'
import PageHeader from '../components/PageHeader'
import { formatBytes, formatDateTime } from '../lib/format'
import { clearExports, listExports } from '../lib/storage'
import { hrefFor } from '../router'

export default function ExportHistory() {
  const [records, setRecords] = useState(listExports)

  function handleClear() {
    if (!window.confirm('Clear this history list? Files already in your Downloads are not touched.')) {
      return
    }
    clearExports()
    setRecords(listExports())
  }

  return (
    <>
      <PageHeader
        title="Export History"
        subtitle="A simple log of text files you downloaded from the editors."
        badges={
          <>
            <Badge tone="local">Works on this device</Badge>
            <Badge tone="off">Video export not connected</Badge>
          </>
        }
      />

      <p className="muted small">
        This list only records downloads you started from a text editor (.txt or .srt). It keeps
        the file name and time, nothing else. The files themselves live in your browser's
        Downloads folder; Harusen does not store them and there are no download links here.
      </p>

      {records.length === 0 ? (
        <section className="card empty">
          <h2>No exports yet</h2>
          <p className="muted">
            Nothing has been exported. In Stage 1 the only thing you can export is your own text,
            using the Download button in an editor. Video and audio export are not connected.
          </p>
          <a className="btn btn--primary" href={hrefFor('/movie-recap')}>
            Go to Movie Recap
          </a>
        </section>
      ) : (
        <>
          <ul className="list">
            {records.map((record) => (
              <li key={record.id} className="card list__item">
                <h2 className="break">{record.filename}</h2>
                <p className="muted small">
                  From {record.source} · {formatBytes(record.bytes)} · {formatDateTime(record.at)}
                </p>
              </li>
            ))}
          </ul>
          <div className="btn-row">
            <button type="button" className="btn btn--danger" onClick={handleClear}>
              Clear history
            </button>
          </div>
        </>
      )}
    </>
  )
}
