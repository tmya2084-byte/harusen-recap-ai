import Badge from '../components/Badge'
import FeaturePanel from '../components/FeaturePanel'
import PageHeader from '../components/PageHeader'
import VideoUpload from '../components/VideoUpload'

export default function BlurStudio() {
  return (
    <>
      <PageHeader
        title="Blur Studio"
        subtitle="Hide faces, logos or text in a video."
        badges={<Badge tone="off">Not connected</Badge>}
      />
      <p className="notice notice--warn" role="note">
        Blur Studio has no working tools in Stage 1. You can only preview a video here. Blurring
        needs a video-processing service that has not been connected.
      </p>
      <VideoUpload title="Video file" />
      <FeaturePanel
        features={[
          {
            label: 'Auto-detect faces and text',
            description: 'Would find things to blur automatically. Needs an AI vision service.',
          },
          {
            label: 'Draw a blur area',
            description: 'Would let you mark an area to hide. Needs a video-processing service.',
          },
          {
            label: 'Apply blur and export',
            description: 'Would render a new video with the blur applied. Needs a video-processing service.',
          },
        ]}
      />
    </>
  )
}
