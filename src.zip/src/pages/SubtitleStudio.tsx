import Badge from '../components/Badge'
import FeaturePanel from '../components/FeaturePanel'
import PageHeader from '../components/PageHeader'
import RecapEditor from '../components/RecapEditor'
import VideoUpload from '../components/VideoUpload'

const SRT_EXAMPLE = `1
00:00:01,000 --> 00:00:03,500
Your first subtitle line

2
00:00:04,000 --> 00:00:06,000
Your second subtitle line`

export default function SubtitleStudio() {
  return (
    <>
      <PageHeader
        title="Subtitle Studio"
        subtitle="Preview a video and write subtitles by hand in .srt format."
        badges={
          <>
            <Badge tone="local">Editor works</Badge>
            <Badge tone="off">Auto-subtitles not connected</Badge>
          </>
        }
      />
      <VideoUpload title="Video file" />
      <RecapEditor
        storageKey="subtitles"
        title="Subtitle text (.srt)"
        draftLabel="Subtitles draft"
        pagePath="/subtitle-studio"
        extension="srt"
        placeholder={SRT_EXAMPLE}
        helpText="Type subtitles in .srt format (see the faded example). The text is not checked or timed for you. It is saved in this browser only."
      />
      <FeaturePanel
        features={[
          {
            label: 'Auto-generate subtitles',
            description: 'Would create timed subtitles from the audio. Needs a speech-to-text service.',
          },
          {
            label: 'Translate subtitles',
            description: 'Would translate subtitle lines. Needs an AI text service.',
          },
          {
            label: 'Burn subtitles into video',
            description: 'Would draw the subtitles onto the video. Needs a video-processing service.',
          },
        ]}
      />
    </>
  )
}
