import Badge from '../components/Badge'
import FeaturePanel from '../components/FeaturePanel'
import PageHeader from '../components/PageHeader'
import RecapEditor from '../components/RecapEditor'
import VideoUpload from '../components/VideoUpload'

export default function ShortDrama() {
  return (
    <>
      <PageHeader
        title="Short Drama"
        subtitle="Preview a short drama episode and write its recap by hand."
        badges={
          <>
            <Badge tone="local">Editor works</Badge>
            <Badge tone="off">AI not connected</Badge>
          </>
        }
      />
      <VideoUpload title="Episode file" />
      <RecapEditor
        storageKey="short-drama"
        title="Episode recap"
        draftLabel="Short Drama draft"
        pagePath="/short-drama"
        placeholder="Write or paste your episode recap here…"
      />
      <FeaturePanel
        features={[
          {
            label: 'Generate episode recap',
            description: 'Would draft a recap of the episode. Needs an AI video-understanding service.',
          },
          {
            label: 'Recap a whole series',
            description: 'Would combine several episodes into one story recap. Needs an AI service.',
          },
          {
            label: 'Export recap video',
            description: 'Would assemble the recap into a video. Needs a video-processing service.',
          },
        ]}
      />
    </>
  )
}
