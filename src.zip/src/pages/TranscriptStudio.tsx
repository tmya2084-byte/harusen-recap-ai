import Badge from '../components/Badge'
import FeaturePanel from '../components/FeaturePanel'
import PageHeader from '../components/PageHeader'
import RecapEditor from '../components/RecapEditor'
import VideoUpload from '../components/VideoUpload'

export default function TranscriptStudio() {
  return (
    <>
      <PageHeader
        title="Transcript Studio"
        subtitle="Play a video or audio file and type its transcript yourself."
        badges={
          <>
            <Badge tone="local">Editor works</Badge>
            <Badge tone="off">Auto-transcription not connected</Badge>
          </>
        }
      />
      <VideoUpload title="Video or audio file" allowAudio />
      <RecapEditor
        storageKey="transcript"
        title="Transcript"
        draftLabel="Transcript draft"
        pagePath="/transcript-studio"
        placeholder="Type or paste the transcript here…"
        helpText="Listen to the file above and type what you hear. Nothing is transcribed automatically, and the text is saved in this browser only."
      />
      <FeaturePanel
        features={[
          {
            label: 'Auto-transcribe',
            description: 'Would turn speech into text. Needs a speech-to-text service.',
          },
          {
            label: 'Detect speakers',
            description: 'Would label who is talking. Needs a speech-to-text service.',
          },
          {
            label: 'Add timestamps',
            description: 'Would line the text up with the audio. Needs a speech-to-text service.',
          },
        ]}
      />
    </>
  )
}
