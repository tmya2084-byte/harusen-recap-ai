import Badge from '../components/Badge'
import FeaturePanel from '../components/FeaturePanel'
import PageHeader from '../components/PageHeader'
import RecapEditor from '../components/RecapEditor'
import VideoUpload from '../components/VideoUpload'

export default function MovieRecap() {
  return (
    <>
      <PageHeader
        title="Movie Recap"
        subtitle="Preview a movie file and write its recap by hand."
        badges={
          <>
            <Badge tone="local">Editor works</Badge>
            <Badge tone="off">AI not connected</Badge>
          </>
        }
      />
      <VideoUpload title="Movie file" />
      <RecapEditor
        storageKey="movie-recap"
        title="Recap text"
        draftLabel="Movie Recap draft"
        pagePath="/movie-recap"
        placeholder="Write or paste your movie recap here…"
      />
      <FeaturePanel
        features={[
          {
            label: 'Generate recap from video',
            description: 'Would watch the movie and draft a recap. Needs an AI video-understanding service.',
          },
          {
            label: 'Detect scenes',
            description: 'Would split the movie into scenes. Needs a video-processing service.',
          },
          {
            label: 'Export recap video',
            description: 'Would combine clips, narration and subtitles into one video. Needs a video-processing service.',
          },
        ]}
      />
    </>
  )
}
