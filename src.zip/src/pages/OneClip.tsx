import Badge from '../components/Badge'
import FeaturePanel from '../components/FeaturePanel'
import PageHeader from '../components/PageHeader'
import RecapEditor from '../components/RecapEditor'
import VideoUpload from '../components/VideoUpload'

export default function OneClip() {
  return (
    <>
      <PageHeader
        title="One Clip"
        subtitle="Preview a single clip and write a short summary of it."
        badges={
          <>
            <Badge tone="local">Editor works</Badge>
            <Badge tone="off">AI not connected</Badge>
          </>
        }
      />
      <VideoUpload title="Clip file" />
      <RecapEditor
        storageKey="one-clip"
        title="Clip summary"
        draftLabel="One Clip draft"
        pagePath="/one-clip"
        placeholder="Write or paste a short summary of the clip here…"
      />
      <FeaturePanel
        features={[
          {
            label: 'Summarise this clip',
            description: 'Would watch the clip and write a summary. Needs an AI video-understanding service.',
          },
          {
            label: 'Suggest best moments',
            description: 'Would pick highlights from the clip. Needs an AI service.',
          },
          {
            label: 'Export clip with recap',
            description: 'Would render the clip with narration. Needs a video-processing service.',
          },
        ]}
      />
    </>
  )
}
