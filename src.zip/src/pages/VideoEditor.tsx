import Badge from '../components/Badge'
import FeaturePanel from '../components/FeaturePanel'
import PageHeader from '../components/PageHeader'
import VideoUpload from '../components/VideoUpload'

export default function VideoEditor() {
  return (
    <>
      <PageHeader
        title="Video Editor"
        subtitle="Trim, join and assemble clips into a finished recap video."
        badges={<Badge tone="off">Not connected</Badge>}
      />
      <p className="notice notice--warn" role="note">
        The Video Editor has no working tools in Stage 1. You can only preview a video here.
        Editing and exporting need a video-processing service that has not been connected.
      </p>
      <VideoUpload title="Video file" />
      <FeaturePanel
        features={[
          {
            label: 'Trim and split',
            description: 'Would cut a video into parts. Needs a video-processing service.',
          },
          {
            label: 'Join clips',
            description: 'Would put several clips together. Needs a video-processing service.',
          },
          {
            label: 'Add narration and subtitles',
            description: 'Would mix in audio and text from the other studios. Needs a video-processing service.',
          },
          {
            label: 'Export video',
            description: 'Would render a finished video file. Needs a video-processing service.',
          },
        ]}
      />
    </>
  )
}
