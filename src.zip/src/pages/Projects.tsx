import { useState } from 'react'
import Badge from '../components/Badge'
import PageHeader from '../components/PageHeader'
import { countWords, excerpt, formatDateTime } from '../lib/format'
import { deleteDraft, listDrafts } from '../lib/storage'
import { hrefFor } from '../router'

export default function Projects() {
  const [drafts, setDrafts] = useState(listDrafts)

  function handleDelete(key: string, label: string) {
    if (!window.confirm(`Delete "${label}"? This cannot be undone.`)) return
    deleteDraft(key)
    setDrafts(listDrafts())
  }

  return (
    <>
      <PageHeader
        title="Projects"
        subtitle="Text drafts you have written, saved in this browser."
        badges={<Badge tone="local">Saved on this device</Badge>}
      />

      <p className="muted small">
        In Stage 1, a project is a text draft. Video files are never stored. Drafts stay on this
        device and in this browser; clearing your browser data removes them.
      </p>

      {drafts.length === 0 ? (
        <section className="card empty">
          <h2>No drafts yet</h2>
          <p className="muted">
            Start typing in any recap, transcript, voice or subtitle editor and your draft will
            show up here automatically.
          </p>
          <a className="btn btn--primary" href={hrefFor('/movie-recap')}>
            Start a Movie Recap
          </a>
        </section>
      ) : (
        <ul className="list">
          {drafts.map((draft) => (
            <li key={draft.key} className="card list__item">
              <div className="card__head">
                <h2>{draft.label}</h2>
                <Badge tone="info">.{draft.extension}</Badge>
              </div>
              <p className="muted small">
                {countWords(draft.text)} words · updated {formatDateTime(draft.updatedAt)}
              </p>
              <p className="excerpt">{excerpt(draft.text, 140)}</p>
              <div className="btn-row">
                <a className="btn btn--primary" href={hrefFor(draft.path)}>
                  Open
                </a>
                <button
                  type="button"
                  className="btn btn--danger"
                  onClick={() => handleDelete(draft.key, draft.label)}
                >
                  Delete
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </>
  )
}
