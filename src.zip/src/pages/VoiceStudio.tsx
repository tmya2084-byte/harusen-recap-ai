import Badge from '../components/Badge'
import FeaturePanel from '../components/FeaturePanel'
import PageHeader from '../components/PageHeader'
import RecapEditor from '../components/RecapEditor'
import VoicePreview from '../components/VoicePreview'

export default function VoiceStudio() {
  return (
    <>
      <PageHeader
        title="Voice Studio"
        subtitle="Write a narration script and hear it with your phone's built-in voice."
        badges={
          <>
            <Badge tone="local">Script editor works</Badge>
            <Badge tone="off">AI voice not connected</Badge>
          </>
        }
      />
      <RecapEditor
        storageKey="voice-script"
        title="Narration script"
        draftLabel="Voice script draft"
        pagePath="/voice-studio"
        placeholder="Write your narration script here…"
      />
      <VoicePreview />
      <FeaturePanel
        features={[
          {
            label: 'Generate AI narration',
            description: 'Would turn the script into a natural AI voice recording. Needs a text-to-speech service.',
          },
          {
            label: 'Choose an AI voice',
            description: 'Would let you pick a voice, language and speed. Needs a text-to-speech service.',
          },
          {
            label: 'Export narration audio',
            description: 'Would give you an audio file. Needs a text-to-speech service.',
          },
        ]}
      />
    </>
  )
}
