import type { BadgeTone } from './components/Badge'
import type { IconName } from './components/Icon'

export interface NavItem {
  path: string
  label: string
  icon: IconName
  summary: string
  /** Short, honest status shown on the dashboard. */
  status: string
  statusTone: BadgeTone
}

export const NAV_ITEMS: NavItem[] = [
  {
    path: '/',
    label: 'Dashboard',
    icon: 'dashboard',
    summary: 'Overview and connection status',
    status: 'Works on this device',
    statusTone: 'local',
  },
  {
    path: '/movie-recap',
    label: 'Movie Recap',
    icon: 'movie',
    summary: 'Preview a movie file and write its recap',
    status: 'Editor only · AI not connected',
    statusTone: 'off',
  },
  {
    path: '/short-drama',
    label: 'Short Drama',
    icon: 'drama',
    summary: 'Recaps for short drama episodes',
    status: 'Editor only · AI not connected',
    statusTone: 'off',
  },
  {
    path: '/one-clip',
    label: 'One Clip',
    icon: 'clip',
    summary: 'Summarise a single clip',
    status: 'Editor only · AI not connected',
    statusTone: 'off',
  },
  {
    path: '/copy-recap',
    label: 'Copy Recap',
    icon: 'copy',
    summary: 'Adapt an existing recap text',
    status: 'Editor only · AI not connected',
    statusTone: 'off',
  },
  {
    path: '/transcript-studio',
    label: 'Transcript Studio',
    icon: 'transcript',
    summary: 'Write and edit transcripts',
    status: 'Editor only · AI not connected',
    statusTone: 'off',
  },
  {
    path: '/voice-studio',
    label: 'Voice Studio',
    icon: 'voice',
    summary: 'Narration scripts and voice',
    status: 'Browser voice preview only',
    statusTone: 'off',
  },
  {
    path: '/subtitle-studio',
    label: 'Subtitle Studio',
    icon: 'subtitle',
    summary: 'Write and edit subtitle (.srt) text',
    status: 'Editor only · AI not connected',
    statusTone: 'off',
  },
  {
    path: '/blur-studio',
    label: 'Blur Studio',
    icon: 'blur',
    summary: 'Hide faces, logos or text in video',
    status: 'Not connected',
    statusTone: 'off',
  },
  {
    path: '/video-editor',
    label: 'Video Editor',
    icon: 'editor',
    summary: 'Trim, join and assemble clips',
    status: 'Not connected',
    statusTone: 'off',
  },
  {
    path: '/projects',
    label: 'Projects',
    icon: 'projects',
    summary: 'Your drafts saved on this device',
    status: 'Works on this device',
    statusTone: 'local',
  },
  {
    path: '/export-history',
    label: 'Export History',
    icon: 'exports',
    summary: 'Text files you have downloaded',
    status: 'Works on this device',
    statusTone: 'local',
  },
]
