// Everything here lives in this browser's localStorage. Nothing is sent to a server.

export interface Draft {
  key: string
  label: string
  path: string
  extension: string
  text: string
  updatedAt: number
}

export interface ExportRecord {
  id: string
  filename: string
  at: number
  bytes: number
  source: string
}

const DRAFT_PREFIX = 'harusen:draft:'
const EXPORTS_KEY = 'harusen:exports'
const MAX_EXPORT_RECORDS = 200

function readItem(key: string): string | null {
  try {
    return window.localStorage.getItem(key)
  } catch {
    return null
  }
}

function writeItem(key: string, value: string): boolean {
  try {
    window.localStorage.setItem(key, value)
    return true
  } catch {
    return false
  }
}

function removeItem(key: string): void {
  try {
    window.localStorage.removeItem(key)
  } catch {
    // Storage is unavailable; there is nothing to remove.
  }
}

function isDraft(value: unknown): value is Draft {
  if (typeof value !== 'object' || value === null) return false
  const v = value as Record<string, unknown>
  return (
    typeof v.key === 'string' &&
    typeof v.label === 'string' &&
    typeof v.path === 'string' &&
    typeof v.extension === 'string' &&
    typeof v.text === 'string' &&
    typeof v.updatedAt === 'number'
  )
}

function isExportRecord(value: unknown): value is ExportRecord {
  if (typeof value !== 'object' || value === null) return false
  const v = value as Record<string, unknown>
  return (
    typeof v.id === 'string' &&
    typeof v.filename === 'string' &&
    typeof v.at === 'number' &&
    typeof v.bytes === 'number' &&
    typeof v.source === 'string'
  )
}

export function loadDraft(key: string): Draft | null {
  const raw = readItem(DRAFT_PREFIX + key)
  if (raw === null) return null
  try {
    const parsed: unknown = JSON.parse(raw)
    return isDraft(parsed) ? parsed : null
  } catch {
    return null
  }
}

/** Saves a draft. Empty text removes the draft so Projects never lists blanks. Returns false if the browser refused. */
export function saveDraft(draft: Draft): boolean {
  if (draft.text.trim() === '') {
    removeItem(DRAFT_PREFIX + draft.key)
    return true
  }
  return writeItem(DRAFT_PREFIX + draft.key, JSON.stringify(draft))
}

export function deleteDraft(key: string): void {
  removeItem(DRAFT_PREFIX + key)
}

export function listDrafts(): Draft[] {
  const drafts: Draft[] = []
  try {
    for (let i = 0; i < window.localStorage.length; i += 1) {
      const storageKey = window.localStorage.key(i)
      if (storageKey !== null && storageKey.startsWith(DRAFT_PREFIX)) {
        const draft = loadDraft(storageKey.slice(DRAFT_PREFIX.length))
        if (draft) drafts.push(draft)
      }
    }
  } catch {
    // Storage is unavailable; return what we have.
  }
  return drafts.sort((a, b) => b.updatedAt - a.updatedAt)
}

export function listExports(): ExportRecord[] {
  const raw = readItem(EXPORTS_KEY)
  if (raw === null) return []
  try {
    const parsed: unknown = JSON.parse(raw)
    return Array.isArray(parsed) ? parsed.filter(isExportRecord) : []
  } catch {
    return []
  }
}

export function addExport(record: Omit<ExportRecord, 'id'>): void {
  const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
  const next = [{ id, ...record }, ...listExports()].slice(0, MAX_EXPORT_RECORDS)
  writeItem(EXPORTS_KEY, JSON.stringify(next))
}

export function clearExports(): void {
  removeItem(EXPORTS_KEY)
}

/** Asks the browser to download the given text as a file. Returns the file size in bytes. */
export function downloadTextFile(filename: string, text: string, mime: string): number {
  const blob = new Blob([text], { type: `${mime};charset=utf-8` })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  link.remove()
  window.setTimeout(() => URL.revokeObjectURL(url), 10000)
  return blob.size
}
